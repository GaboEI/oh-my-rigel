import { BaseRenderable, type RenderContext } from "@opentui/core";
import { SlotRenderable } from "./elements/index.js";
export type DomNode = BaseRenderable;
/** @internal Portal allocation target, separate from the renderer exposed to application hooks. */
export declare const RenderableContext: import("solid-js").Context<(() => RenderContext) | undefined>;
declare function _removeNode(parent: DomNode, node: DomNode): void;
export { _removeNode as removeNode };
export declare function createSlotNode(): SlotRenderable;
declare const effect: <T>(fn: (prev?: T) => T, init?: T) => void, memo: <T>(fn: () => T, equal: boolean) => () => T, createComponent: <T>(Comp: (props: T) => unknown, props: T) => BaseRenderable, createElement: (tag: string) => BaseRenderable, createTextNode: (value: string) => BaseRenderable, insertNode: (parent: BaseRenderable, node: BaseRenderable, anchor?: BaseRenderable | undefined) => void, insert: <T>(parent: any, accessor: T | (() => T), marker?: any | null, initial?: any) => BaseRenderable, spread: <T>(node: any, accessor: (() => T) | T, skipChildren?: boolean) => void, setProp: <T>(node: BaseRenderable, name: string, value: T, prev?: T | undefined) => T, mergeProps: (...sources: unknown[]) => unknown, use: <A, T>(fn: (element: BaseRenderable, arg: A) => T, element: BaseRenderable, arg: A) => T;
export { effect, memo, createComponent, createElement, createTextNode, insertNode, insert, spread, setProp, mergeProps, use, };
/** @internal Start an independent root without inheriting a Portal allocation target. */
export declare function _render(code: () => DomNode, root: DomNode): () => void;

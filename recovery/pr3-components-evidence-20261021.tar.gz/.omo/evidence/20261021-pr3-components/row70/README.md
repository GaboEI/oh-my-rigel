# ROW 70 - `cat:K:bucle-de-trabajo-de-codex` (Codex work loop) - EVIDENCE

Verdict: **PASS after a production fix** (the capability is real and reachable;
it was silently broken on real Codex turns and is now proven end to end).

Component: `packages/omo-codex/plugin/components/ulw-loop`
Codex under test: `codex-cli 0.162.1` (the real binary on PATH)
Isolated home: `CODEX_HOME=/tmp/opencode/row70/codex` (this repo's LOCAL build
5.1.10, never the published package, never the real `~/.codex`)

## WHAT WAS TESTED

| # | Surface driven | Command / mechanism | Artifact |
|---|---|---|---|
| 1 | Official local install into an isolated `CODEX_HOME` | `node packages/omo-codex/scripts/install-local.mjs install` | `install-isolated.txt` |
| 2 | Plugin enabled + hook trust + bins in the sandbox | inspect `$CODEX_HOME/config.toml`, `$CODEX_HOME/bin` | `install-isolated.txt` |
| 3 | Repo QA skill: install proof | `.agents/skills/codex-qa/scripts/install-verify.sh --self-test` | `install-verify.txt` |
| 4 | Repo QA skill: live app-server drive with the plugin | `.agents/skills/codex-qa/scripts/app-server-drive.sh --plugin --expect sessionStart,userPromptSubmit,stop` | `app-server-drive.txt` |
| 5 | Repo QA skill: component hook probe | `.agents/skills/codex-qa/scripts/hook-unit-probe.sh --self-test` | `hook-unit-probe.txt` |
| 6 | REAL Stop payload capture (only the isolated copy instrumented: the Stop command's stdin teed to a temp file; the hook manifest was NOT touched, so the trust hash stayed valid) | `codex app-server` turn against the local mock model | `raw/stop-stdin-raw-*.json`, `raw/capture-*.ndjson` |
| 7 | Codex's own contract for the Stop hook | `stop.command.input` / `stop.command.output` JSON schemas extracted verbatim from the shipped codex binary | `codex-stop-hook-schema.json` |
| 8 | Field-by-field payload vs. `parseStopPayload()` | manual comparison | `payload-vs-parser.txt` |
| 9 | Decision with the REAL payload, seeded plan (unfinished / all complete / no plan) | `node <isolated>/components/ulw-loop/dist/cli.js hook stop` | `block-decision.txt`, `no-block-plan-complete.txt`, `no-block-no-plan.txt`, `decision-proofs.txt` |
| 10 | Same decision on the PRE-FIX build (git HEAD source) | same CLI, pre-fix bundle | `prefix-cli-decision.txt` |
| 11 | RED -> GREEN regression | `npm --prefix packages/omo-codex/plugin/components/ulw-loop test` | `red.txt`, `green.txt` |
| 12 | Live loop: does Codex really resume? | app-server event stream hook status + model request count | `live-loop-fixed.txt`, `live-loop-prefix.txt`, `live-loop-fixed-null-message.txt`, `live-loop-prefix-null-message.txt` |
| 13 | Installer guard + repo typecheck | `node --test packages/omo-codex/scripts/install-hook-targets.test.mjs`, `bun run typecheck` | `gate-install-hook-targets.txt`, `typecheck.txt` |
| 14 | Real home untouched | sha256 of `~/.codex/config.toml` before/after | `isolation.txt` |
| 15 | Working tree hygiene | `git status --porcelain=v1` before/after | `clean-tree.txt` |

Reproducer scripts: `scripts/` (all paths under `/tmp/opencode/row70`).

## WHAT WAS OBSERVED

* C70.1 install: PASS. The plugin cache exists with
  `components/ulw-loop/dist/cli.js`; `config.toml` contains
  `[plugins."omo@sisyphuslabs"] enabled = true` plus 21 `hooks.state` trust
  entries; `omo-ulw-loop` / `ulw` / `ulw-loop` are linked into
  `$CODEX_HOME/bin`. The real `~/.codex/config.toml` is byte-identical
  (sha256 `a74aa65a...` before and after, mtime still 2026-10-20 20:11:33).
* C70.2 real payload: the Stop hook FIRED in a real Codex 0.162.1 app-server
  turn (hook run `stop:17:.../hooks/stop-checking-ulw-loop-resume.json`,
  status `completed`). Codex sent EVERY key its schema marks required. The one
  deviation from the parser's expectation: **`last_assistant_message: null`**
  on a turn that ended without an assistant message (Codex types it
  `NullableString` in `stop.command.input`). `transcript_path` was a string in
  both captures, but Codex also declares it `NullableString`.
* C70.3 decision (fixed build, REAL payload): unfinished plan -> 743 bytes
  `{"decision":"block","reason":"..."}`; all goals complete -> 0 bytes; no plan
  -> 0 bytes. Pre-fix build with the same payload and the same seeded plan ->
  **0 bytes** (silent).
* C70.4 defect: PROVEN and FIXED. RED: 2 failing cases in
  `test/stop-resume-hook.test.ts` (`SyntaxError: Unexpected end of JSON input`
  because the hook returned the empty string). GREEN: 66 files / 683 tests pass
  after the null-tolerant parser.
* Live loop, real Codex, turn WITHOUT an assistant message:
  pre-fix -> 0 `blocked` hook statuses and 2 model requests (the loop never
  resumed); fixed -> 1 `blocked` hook status and 3 model requests (Codex
  re-prompted the model inside the turn). Codex itself reports the Stop hook
  run status as `blocked`, so the `{"decision":"block"}` output is honored.
  With a normal assistant message both builds block and resume (3 requests).
* The auto-resume budget stayed at 1 consumption per blocked turn
  (`auto-resume-g1.json` = `{"count":1,...}`); Codex's own `stop_hook_active`
  flag ends the resumed turn, so no runaway loop.

## WHY IT IS ENOUGH

The claim of row 70 is "the Codex work loop is a real, reachable capability".
That claim needs three independent facts, and all three are now measured
against a real `codex` 0.162.1 process instead of a synthetic payload:
(1) the loop is installed and trusted in a real Codex home
(`install-isolated.txt`, `install-verify.txt`); (2) the Stop hook really fires
in a real turn and Codex sends a payload the component can act on
(`app-server-drive.txt`, `raw/`, `codex-stop-hook-schema.json`); (3) the hook's
decision changes real Codex behavior - it blocks, Codex re-prompts the model,
and the model request count goes up (`live-loop-*.txt`). The remaining risk is
narrow and measured: the fix only widens payload acceptance for two fields
Codex itself declares nullable; no output, path, CLI surface, resume-cap or
budget semantics changed, and all 683 pre-existing component tests still pass.

## WHAT WAS OMITTED

* No secret, token, auth header or credential value appears in any artifact.
* The codex binary paths (`/home/gabodev/.local/lib/node_modules/@openai/codex/...`)
  and the sandbox paths (`/tmp/opencode/row70/...`) are environment paths, not
  secrets. The captured payloads contain only Codex's own session/turn UUIDs,
  a mock model name and sandbox paths.
* The `stderrTail` sections in `app-server-drive.txt` and `live-loop-*.txt`
  contain Codex's own startup log lines (credential-storage fallback warnings
  with `outcome: not_found`, and a `401 Unauthorized` from Codex's optional
  "featured plugins" call to chatgpt.com). They are reproduced verbatim because
  they are part of the QA transcript; no credential material is in them.
* The mock model is a local HTTP server on 127.0.0.1 that speaks the Responses
  SSE protocol. No real OpenAI API call was made, so the "assistant message"
  content of the transcript is mock text, not model output.
* One real-Codex behavior was NOT reproduced: a null `transcript_path`. Codex
  declares it `NullableString`, so the parser now tolerates it, but only the
  `last_assistant_message: null` case was observed live.
* The sibling component `ulw-execute-continuation` has the same over-strict
  Stop parser and was deliberately NOT changed here (different audit row). See
  `payload-vs-parser.txt`, section 5.

## HASHES OF THE EVIDENCE FILES

Run `sha256sum .omo/evidence/20261021-pr3-components/row70/*` to check them
against the reviewer's copy; the digests are listed in `sha256sums.txt`.

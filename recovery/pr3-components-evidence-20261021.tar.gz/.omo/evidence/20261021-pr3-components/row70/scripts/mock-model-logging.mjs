// mock-model-logging.mjs - local Responses-API SSE server that LOGS every
// model request it receives (one line per POST) so a driver can count how many
// model turns a Codex session actually ran.
//
// Used by the row70 live loop proof: when the ulw-loop Stop hook answers
// {"decision":"block"}, Codex re-prompts the model inside the same turn, so the
// request count is the observable proof that the work loop resumed.
import { createServer } from "node:http";
import { appendFileSync } from "node:fs";

const TEXT = process.env.MOCK_TEXT || "Hello from the codex-qa mock model.";
const REQUEST_LOG = process.env.MOCK_REQUEST_LOG;

const server = createServer((req, res) => {
	if (req.method === "POST" && req.url && req.url.endsWith("/responses")) {
		let body = "";
		req.on("data", (c) => (body += c));
		req.on("end", () => {
			if (REQUEST_LOG) {
				let preview = "";
				try {
					const parsed = JSON.parse(body);
					const input = Array.isArray(parsed.input) ? parsed.input : [];
					preview = input
						.map((item) => (typeof item?.content === "string" ? item.content : JSON.stringify(item)))
						.join(" | ")
						.slice(0, 400);
				} catch (error) {
					preview = `<unparsed body: ${error instanceof Error ? error.message : String(error)}>`;
				}
				appendFileSync(REQUEST_LOG, `${JSON.stringify({ at: new Date().toISOString(), preview })}\n`);
			}
			res.writeHead(200, {
				"Content-Type": "text/event-stream",
				"Cache-Control": "no-cache",
				Connection: "keep-alive",
			});
			const sse = (obj) => res.write(`event: ${obj.type}\ndata: ${JSON.stringify(obj)}\n\n`);
			sse({ type: "response.created", response: { id: "resp-1" } });
			sse({
				type: "response.output_item.done",
				item: {
					type: "message",
					role: "assistant",
					id: "msg-1",
					content: [{ type: "output_text", text: TEXT }],
				},
			});
			sse({
				type: "response.completed",
				response: { id: "resp-1", usage: { input_tokens: 0, output_tokens: 0, total_tokens: 0 } },
			});
			res.end();
		});
		return;
	}
	res.writeHead(404).end();
});

const port = Number(process.env.MOCK_PORT || 0);
server.listen(port, "127.0.0.1", () => {
	process.stdout.write(`MOCK_LISTENING ${server.address().port}\n`);
});

// instrument-stop-hook.mjs - wrap the ISOLATED plugin's ulw-loop dist/cli.js so
// every stdin payload the real Codex Stop hook sends is captured verbatim,
// then the REAL cli runs with the SAME stdin and stdout/stderr are forwarded.
//
// This touches ONLY the throwaway CODEX_HOME at /tmp/opencode/row70/codex.
import { spawn } from "node:child_process";
import { appendFileSync, copyFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const distDir = process.argv[2];
const captureFile = process.argv[3];
if (!distDir || !captureFile) {
	console.error("usage: instrument-stop-hook.mjs <dist-dir> <capture-file>");
	process.exit(2);
}

const cliPath = join(distDir, "cli.js");
const realPath = join(distDir, "cli.real.js");
copyFileSync(cliPath, realPath);

const wrapper = `#!/usr/bin/env node
// row70 QA wrapper: tee stdin (the real Codex hook payload) then exec the real CLI.
import { spawn } from "node:child_process";
import { appendFileSync } from "node:fs";
import { join } from "node:path";

const captureFile = process.env.ROW70_STOP_CAPTURE;
const chunks = [];
for await (const chunk of process.stdin) chunks.push(chunk);
const buffer = Buffer.concat(chunks);
if (captureFile) {
	appendFileSync(captureFile, JSON.stringify({
		capturedAt: new Date().toISOString(),
		argv: process.argv.slice(2),
		raw: buffer.toString("utf8"),
	}) + "\\n");
}
const realPath = join(new URL(".", import.meta.url).pathname, "cli.real.js");
const child = spawn(process.execPath, [realPath, ...process.argv.slice(2)], { stdio: ["pipe", "inherit", "inherit"] });
child.stdin.end(buffer);
child.on("exit", (code, signal) => {
	if (signal) process.kill(process.pid, signal);
	else process.exit(code === null ? 1 : code);
});
`;

writeFileSync(cliPath, wrapper);
console.log(`instrumented ${cliPath}`);
console.log(`  real cli preserved at ${realPath}`);
console.log(`  capture file ${captureFile}`);
console.log(`  wrapper dir ${dirname(cliPath)}`);
void fileURLToPath;

// row70-loop-driver.mjs - live proof that the ulw-loop Stop hook actually
// resumes a Codex turn.
//
// 1. thread/start + turn/start with NO ulw-loop plan on disk.
//    -> the Stop hook stays silent, the turn ends after ONE model request.
// 2. Seed the plan under the session id Codex itself reported in the Stop hook
//    payload (captured by the instrumented hook), then run a SECOND turn in the
//    SAME thread.
//    -> the Stop hook answers {"decision":"block"}, Codex re-prompts the model
//       inside that turn, and the model request count for the turn goes UP.
//
// The observable is the number of model requests the mock server received.
import { spawn, spawnSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { pathToFileURL } from "node:url";

const CODEX_BIN = process.env.CODEX_BIN || "codex";
const CWD = process.env.QA_CWD || process.cwd();
const MOCK_PORT = process.env.MOCK_PORT;
const DEADLINE_MS = Number(process.env.DEADLINE_MS || 120000);
const CAPTURE = process.env.ROW70_STOP_CAPTURE;
const PLAN_SEED_SCRIPT = process.env.ROW70_SEED_SCRIPT;
const EXPECT_SESSION_FILE = process.env.ROW70_SESSION_FILE;

if (!MOCK_PORT) {
	console.error("MOCK_PORT is required");
	process.exit(2);
}

const overrides = [
	`model="mock-model"`,
	`model_provider="mock_provider"`,
	`model_providers.mock_provider.name="codex-qa mock"`,
	`model_providers.mock_provider.base_url="http://127.0.0.1:${MOCK_PORT}/v1"`,
	`model_providers.mock_provider.wire_api="responses"`,
	`model_providers.mock_provider.request_max_retries=0`,
	`model_providers.mock_provider.stream_max_retries=0`,
	`approval_policy="never"`,
	`sandbox_mode="read-only"`,
];
const args = overrides.flatMap((o) => ["-c", o]).concat("app-server");
const child = spawn(CODEX_BIN, args, { stdio: ["pipe", "pipe", "pipe"], env: process.env });

let stderr = "";
child.stderr.on("data", (chunk) => (stderr += chunk));

const events = [];
let threadId = null;
let turnCount = 0;
let buf = "";
let finished = false;
let currentTurn = 0;

const send = (obj) => child.stdin.write(`${JSON.stringify(obj)}\n`);

function finish(summary) {
	if (finished) return;
	finished = true;
	try {
		child.kill("SIGTERM");
	} catch (error) {
		stderr += `\n[driver] kill failed: ${error instanceof Error ? error.message : String(error)}`;
	}
	console.log(JSON.stringify({ ...summary, events, stderrTail: stderr.split("\n").slice(-12).join("\n") }, null, 2));
	process.exit(summary.ok ? 0 : 1);
}

function captureCount() {
	if (!CAPTURE || !existsSync(CAPTURE)) return 0;
	return readFileSync(CAPTURE, "utf8")
		.split("\n")
		.filter((line) => line.trim().length > 0)
		.map((line) => JSON.parse(line))
		.filter((record) => record.argv.includes("stop")).length;
}

function handle(msg) {
	if (msg.id === 1 && msg.result) {
		send({ method: "initialized" });
		send({ id: 2, method: "thread/start", params: { cwd: CWD } });
		return;
	}
	if (msg.id === 2 && msg.result) {
		threadId = msg.result.thread?.id;
		currentTurn = 1;
		send({ id: 3, method: "turn/start", params: { threadId, input: [{ type: "text", text: "ulw: say hello" }] } });
		return;
	}
	if (msg.id === 3 && msg.result) {
		// turn 1 started
	}
	if (msg.method === "hook/started" || msg.method === "hook/completed") {
		const run = msg.params?.run || {};
		events.push({ method: msg.method, eventName: run.eventName, status: run.status, runId: run.id });
		return;
	}
	if (msg.method === "turn/started") {
		turnCount += 1;
		events.push({ method: "turn/started", turnCount });
		return;
	}
	if (msg.method === "turn/completed") {
		const status = msg.params?.turn?.status;
		events.push({ method: "turn/completed", turn: currentTurn, status });
		if (currentTurn === 1) {
			// The first turn ended with no plan on disk: the hook stayed silent.
			// Seed the plan under the session id Codex reported, then run turn 2.
			const sessionId = readSessionId();
			if (sessionId === null) {
				finish({ ok: false, reason: "no stop payload captured for turn 1" });
				return;
			}
			const seeded = spawnSyncSeed(sessionId);
			if (!seeded.ok) {
				finish({ ok: false, reason: `plan seed failed: ${seeded.detail}` });
				return;
			}
			events.push({ method: "driver/seeded-plan", sessionId, detail: seeded.detail });
			currentTurn = 2;
			send({ id: 4, method: "turn/start", params: { threadId, input: [{ type: "text", text: "ulw: continue" }] } });
			return;
		}
		finish({ ok: true, reason: "both turns completed", threadId, turnCount, stopPayloads: captureCount() });
	}
}

function readSessionId() {
	if (CAPTURE && existsSync(CAPTURE)) {
		const records = readFileSync(CAPTURE, "utf8")
			.split("\n")
			.filter((line) => line.trim().length > 0)
			.map((line) => JSON.parse(line))
			.filter((record) => record.argv.includes("stop"));
		const last = records[records.length - 1];
		if (last) {
			try {
				return JSON.parse(last.raw).session_id;
			} catch (error) {
				return null;
			}
		}
	}
	if (EXPECT_SESSION_FILE && existsSync(EXPECT_SESSION_FILE)) {
		return readFileSync(EXPECT_SESSION_FILE, "utf8").trim();
	}
	return null;
}

function spawnSyncSeed(sessionId) {
	const result = spawnSyncSafe(process.execPath, [PLAN_SEED_SCRIPT, CWD, sessionId, "pending"]);
	const stdout = typeof result.stdout === "string" ? result.stdout : "";
	const stderr = typeof result.stderr === "string" ? result.stderr : String(result.error ?? "");
	return { ok: result.status === 0, detail: stdout.trim() || stderr.trim() };
}

function spawnSyncSafe(command, args) {
	return spawnSync(command, args, { encoding: "utf8" });
}

child.stdout.on("data", (chunk) => {
	buf += chunk;
	let nl;
	while ((nl = buf.indexOf("\n")) >= 0) {
		const line = buf.slice(0, nl).trim();
		buf = buf.slice(nl + 1);
		if (!line) continue;
		let msg;
		try {
			msg = JSON.parse(line);
		} catch (error) {
			if (error instanceof SyntaxError) continue;
			throw error;
		}
		handle(msg);
	}
});

child.on("exit", (code) => {
	if (finished) return;
	finish({ ok: false, reason: "app-server exited early", exitCode: code });
});

send({ id: 1, method: "initialize", params: { clientInfo: { name: "row70-loop", version: "0.1.0" }, capabilities: { experimentalApi: true, requestAttestation: false } } });
setTimeout(() => finish({ ok: false, reason: "deadline reached" }), DEADLINE_MS);

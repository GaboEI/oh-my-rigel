#!/usr/bin/env bash
# row70-drive-stop.sh - drive a REAL codex app-server turn against the
# ISOLATED CODEX_HOME at $ROW70_CODEX_HOME (plugin already installed there),
# with the local mock model, and capture the REAL Stop hook payload.
#
# Uses the repo's shared codex-qa helpers READ-ONLY:
#   .agents/skills/codex-qa/scripts/lib/mock-model.mjs
#   .agents/skills/codex-qa/scripts/lib/app-server-client.mjs
set -uo pipefail

REPO_ROOT="${REPO_ROOT:?}"
ROW70_CODEX_HOME="${ROW70_CODEX_HOME:?}"
ROW70_PROJ="${ROW70_PROJ:?}"
ROW70_CAPTURE="${ROW70_CAPTURE:?}"
SKILL_LIB="$REPO_ROOT/.agents/skills/codex-qa/scripts/lib"

export CODEX_HOME="$ROW70_CODEX_HOME"
export CODEX_LOCAL_BIN_DIR="$ROW70_CODEX_HOME/bin"
export OMO_DISABLE_POSTHOG=1
export OMO_CODEX_DISABLE_POSTHOG=1
export QA_CWD="$ROW70_PROJ"
export ROW70_STOP_CAPTURE="$ROW70_CAPTURE"

MOCK_LOG="$(mktemp -t row70-mock.XXXXXX)"
node "/tmp/opencode/row70/mock-model-no-message.mjs" >"$MOCK_LOG" 2>&1 &
MOCK_PID=$!
trap 'kill $MOCK_PID 2>/dev/null || true; rm -f "$MOCK_LOG"' EXIT

MOCK_PORT=""
for _ in $(seq 1 100); do
	MOCK_PORT="$(awk '/MOCK_LISTENING/{print $2; exit}' "$MOCK_LOG" 2>/dev/null)"
	[ -n "$MOCK_PORT" ] && break
	kill -0 "$MOCK_PID" 2>/dev/null || { echo "mock model died:"; cat "$MOCK_LOG"; exit 1; }
	sleep 0.1
done
[ -n "$MOCK_PORT" ] || { echo "mock model never reported a port"; cat "$MOCK_LOG"; exit 1; }
export MOCK_PORT
echo "MOCK_PORT=$MOCK_PORT"

EXPECT_HOOK="${EXPECT_HOOK:-sessionStart,userPromptSubmit,stop}" \
PROMPT="${PROMPT:-ulw: say hello}" \
DEADLINE_MS="${DEADLINE_MS:-90000}" \
	node "$SKILL_LIB/app-server-client.mjs"
RC=$?
echo "DRIVER_EXIT=$RC"
exit $RC

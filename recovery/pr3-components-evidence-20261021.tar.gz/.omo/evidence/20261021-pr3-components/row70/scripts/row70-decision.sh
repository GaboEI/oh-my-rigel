#!/usr/bin/env bash
# row70-decision.sh - prove the ulw-loop Stop decision with the REAL Codex
# 0.162.1 Stop payload against the REAL component CLI from the isolated install.
#
# usage: row70-decision.sh <plugin-root> <payload-file> <out-file> [cwd-override]
#
#   plugin-root   isolated plugin cache dir (contains components/ulw-loop/dist/cli.js)
#   payload-file  the captured real Stop payload (raw stdin bytes)
#   out-file      where to write the verbatim stdout of the hook
#   cwd-override  optional cwd to inject into the payload (for the extra workspaces)
set -uo pipefail

PLUGIN_ROOT="${1:?}"
PAYLOAD_FILE="${2:?}"
OUT="${3:?}"
CWD_OVERRIDE="${4:-}"

CLI="$PLUGIN_ROOT/components/ulw-loop/dist/cli.js"
[ -f "$CLI" ] || { echo "missing component CLI: $CLI" >&2; exit 1; }
[ -f "$PAYLOAD_FILE" ] || { echo "missing payload file: $PAYLOAD_FILE" >&2; exit 1; }

PAYLOAD="$(cat "$PAYLOAD_FILE")"

if [ -n "$CWD_OVERRIDE" ]; then
	PAYLOAD="$(node -e '
		const fs = require("node:fs");
		const payload = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
		payload.cwd = process.argv[2];
		process.stdout.write(JSON.stringify(payload));
	' "$PAYLOAD_FILE" "$CWD_OVERRIDE")"
fi

printf '%s' "$PAYLOAD" | node "$CLI" hook stop >"$OUT" 2>"$OUT.stderr"
RC=$?
{
	echo "### command: printf '%s' <captured real Stop payload> | node $CLI hook stop"
	echo "### payload file: $PAYLOAD_FILE"
	echo "### exit code: $RC"
	echo "### stdout bytes: $(wc -c <"$OUT")"
	echo "### stdout (verbatim):"
	cat "$OUT"
	echo
	echo "### stderr (verbatim):"
	cat "$OUT.stderr"
} >&2
exit $RC

// extract-stop-payload.mjs - turn the captured hook stdin records into
// reviewer-readable evidence files: the RAW stdin bytes plus a pretty-printed
// copy of the same JSON.
import { readFileSync, writeFileSync } from "node:fs";

const [ndjsonPath, outDir] = process.argv.slice(2);
const records = readFileSync(ndjsonPath, "utf8")
	.split("\n")
	.filter((line) => line.trim().length > 0)
	.map((line) => JSON.parse(line));

const stop = records.filter((record) => record.argv.includes("stop"));
if (stop.length === 0) throw new Error(`no stop record in ${ndjsonPath}`);

for (const [index, record] of stop.entries()) {
	const suffix = stop.length === 1 ? "" : `-${index + 1}`;
	writeFileSync(`${outDir}/stop-stdin-raw${suffix}.json`, record.raw);
	writeFileSync(`${outDir}/stop-stdin-pretty${suffix}.json`, `${JSON.stringify(JSON.parse(record.raw), null, 2)}\n`);
	console.log(`wrote ${outDir}/stop-stdin-raw${suffix}.json`);
	console.log(`wrote ${outDir}/stop-stdin-pretty${suffix}.json`);
}

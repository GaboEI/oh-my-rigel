#!/usr/bin/env bash
# row70-live-loop.sh - live end-to-end proof that the ulw-loop Stop hook makes
# Codex RESUME the turn (the "Codex work loop"), using the fixed build in the
# isolated CODEX_HOME.
#
# Turn 1: no plan on disk -> the Stop hook stays silent -> ONE model request.
# Then the driver seeds the plan under the session id Codex reported and runs
# turn 2 in the same thread: the Stop hook blocks, Codex re-prompts the model
# inside the turn, and the model request count for turn 2 goes UP.
set -uo pipefail

REPO_ROOT="${REPO_ROOT:?}"
ROW70_CODEX_HOME="${ROW70_CODEX_HOME:?}"
ROW70_PROJ="${ROW70_PROJ:?}"
ROW70_CAPTURE="${ROW70_CAPTURE:?}"
ROW70_REQUEST_LOG="${ROW70_REQUEST_LOG:?}"

export CODEX_HOME="$ROW70_CODEX_HOME"
export CODEX_LOCAL_BIN_DIR="$ROW70_CODEX_HOME/bin"
export OMO_DISABLE_POSTHOG=1
export OMO_CODEX_DISABLE_POSTHOG=1
export QA_CWD="$ROW70_PROJ"
export ROW70_STOP_CAPTURE="$ROW70_CAPTURE"
export MOCK_REQUEST_LOG="$ROW70_REQUEST_LOG"
export ROW70_SEED_SCRIPT=/tmp/opencode/row70/row70-seed-plan.mjs

MOCK_LOG="$(mktemp -t row70-mock.XXXXXX)"
node "${MOCK_SCRIPT:-/tmp/opencode/row70/mock-model-logging.mjs}" >"$MOCK_LOG" 2>&1 &
MOCK_PID=$!
trap 'kill $MOCK_PID 2>/dev/null || true; rm -f "$MOCK_LOG"' EXIT

MOCK_PORT=""
for _ in $(seq 1 100); do
	MOCK_PORT="$(awk '/MOCK_LISTENING/{print $2; exit}' "$MOCK_LOG" 2>/dev/null)"
	[ -n "$MOCK_PORT" ] && break
	kill -0 "$MOCK_PID" 2>/dev/null || { echo "mock model died:"; cat "$MOCK_LOG"; exit 1; }
	sleep 0.1
done
[ -n "$MOCK_PORT" ] || { echo "mock model never reported a port"; cat "$MOCK_LOG"; exit 1; }
export MOCK_PORT
echo "MOCK_PORT=$MOCK_PORT"

node /tmp/opencode/row70/row70-loop-driver.mjs
RC=$?
echo "DRIVER_EXIT=$RC"
echo "=== model requests received by the mock ==="
wc -l <"$ROW70_REQUEST_LOG" || true
cat "$ROW70_REQUEST_LOG" || true
exit $RC

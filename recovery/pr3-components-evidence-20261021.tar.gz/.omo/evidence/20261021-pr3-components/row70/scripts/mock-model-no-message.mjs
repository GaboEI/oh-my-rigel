// mock-model-no-message.mjs - a local Responses-API SSE server that answers with
// NO assistant message (no response.output_item.done), so Codex ends the turn
// without a final assistant message.
//
// Purpose (row70): determine whether real Codex 0.162.1 sends
// `last_assistant_message: null` in the Stop hook payload when the turn produced
// no assistant message. The shipped codex binary declares the field as
// NullableString in its embedded `stop.command.input` schema.
//
// The shared codex-qa mock (lib/mock-model.mjs) is used unmodified for the
// baseline run; this variant only removes the assistant message event.
import { createServer } from "node:http";
import { appendFileSync } from "node:fs";

const server = createServer((req, res) => {
	if (req.method === "POST" && req.url && req.url.endsWith("/responses")) {
		let body = "";
		req.on("data", (c) => (body += c));
		req.on("end", () => {
			if (process.env.MOCK_REQUEST_LOG) {
				appendFileSync(process.env.MOCK_REQUEST_LOG, `${JSON.stringify({ at: new Date().toISOString(), bodyBytes: body.length })}\n`);
			}
			res.writeHead(200, {
				"Content-Type": "text/event-stream",
				"Cache-Control": "no-cache",
				Connection: "keep-alive",
			});
			const sse = (obj) => res.write(`event: ${obj.type}\ndata: ${JSON.stringify(obj)}\n\n`);
			sse({ type: "response.created", response: { id: "resp-1" } });
			// NOTE: deliberately no response.output_item.done -> no assistant message.
			sse({
				type: "response.completed",
				response: { id: "resp-1", usage: { input_tokens: 0, output_tokens: 0, total_tokens: 0 } },
			});
			res.end();
		});
		return;
	}
	res.writeHead(404).end();
});

const port = Number(process.env.MOCK_PORT || 0);
server.listen(port, "127.0.0.1", () => {
	process.stdout.write(`MOCK_LISTENING ${server.address().port}\n`);
});

#!/usr/bin/env bash
# row70-fresh-home.sh - (re)create a CLEAN isolated CODEX_HOME with THIS repo's
# local build installed, and PIN the plugin auto-update so the SessionStart
# auto-update hook cannot replace the local build with the published npm package
# mid-QA (observed: it installed lazycodex-ai@latest 5.1.40 over the local
# 5.1.10 build inside the sandbox).
set -euo pipefail

REPO_ROOT="${REPO_ROOT:?}"
CODEX_HOME_DIR="${CODEX_HOME_DIR:?}"

rm -rf "$CODEX_HOME_DIR"
mkdir -p "$CODEX_HOME_DIR" "$CODEX_HOME_DIR/bin"

export CODEX_HOME="$CODEX_HOME_DIR"
export CODEX_LOCAL_BIN_DIR="$CODEX_HOME_DIR/bin"
export OMO_DISABLE_POSTHOG=1
export OMO_CODEX_DISABLE_POSTHOG=1

node "$REPO_ROOT/packages/omo-codex/scripts/install-local.mjs" install >"$CODEX_HOME_DIR/install.log" 2>&1
echo "install exit=$?"

VERSION_DIR="$(ls -d "$CODEX_HOME_DIR"/plugins/cache/sisyphuslabs/omo/*/ | head -1)"
echo "installed version dir: $VERSION_DIR"

# Pin the auto-update: mark a fresh successful check so the 24h throttle
# short-circuits the update plan and the local build stays installed.
STATE_DIR="$CODEX_HOME_DIR/plugins/data/omo-sisyphuslabs"
mkdir -p "$STATE_DIR"
NOW_MS="$(date +%s000)"
cat >"$STATE_DIR/auto-update.json" <<JSON
{
  "lastCheckedAt": $NOW_MS,
  "lastAttemptedAt": $NOW_MS,
  "lastStatus": "success"
}
JSON
echo "pinned auto-update state: $STATE_DIR/auto-update.json"
cat "$STATE_DIR/auto-update.json"

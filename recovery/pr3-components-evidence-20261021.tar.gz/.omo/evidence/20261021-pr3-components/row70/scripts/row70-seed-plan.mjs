// row70-seed-plan.mjs - seed a ulw-loop plan on disk in the component's real
// on-disk format (goals.json + ledger.jsonl under
// <workspace>/.omo/ulw-loop/<sessionId>/), exactly the shape the component's
// own plan reader accepts.
//
// usage: node row70-seed-plan.mjs <workspace> <sessionId> <pending|complete>
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const [workspace, sessionId, mode] = process.argv.slice(2);
if (!workspace || !sessionId || !mode) {
	console.error("usage: row70-seed-plan.mjs <workspace> <sessionId> <pending|complete>");
	process.exit(2);
}

const status = mode === "complete" ? "complete" : "pending";
const dir = join(workspace, ".omo", "ulw-loop", sessionId);
mkdirSync(dir, { recursive: true });

const plan = {
	version: 1,
	createdAt: "2026-10-21T00:00:00.000Z",
	updatedAt: "2026-10-21T00:00:00.000Z",
	briefPath: `.omo/ulw-loop/${sessionId}/brief.md`,
	goalsPath: `.omo/ulw-loop/${sessionId}/goals.json`,
	ledgerPath: `.omo/ulw-loop/${sessionId}/ledger.jsonl`,
	codexGoalMode: "aggregate",
	goals: [
		{
			id: "g1",
			title: "Goal g1",
			objective: "Objective g1",
			status,
			successCriteria: [],
			attempt: 1,
			createdAt: "2026-10-21T00:00:00.000Z",
			updatedAt: "2026-10-21T00:00:00.000Z",
		},
	],
};

writeFileSync(join(dir, "goals.json"), `${JSON.stringify(plan, null, 2)}\n`);
writeFileSync(join(dir, "ledger.jsonl"), "");
writeFileSync(join(dir, "brief.md"), "# Brief\n\nRow 70 Codex work-loop proof.\n");
console.log(`seeded ${dir}/goals.json (goal g1 status=${status})`);

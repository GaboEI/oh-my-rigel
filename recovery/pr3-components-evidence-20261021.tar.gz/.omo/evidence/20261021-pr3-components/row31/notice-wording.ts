// notice-wording.ts - prints the real tool output the comment-checker hook produces
// when the checker cannot run, plus the bounded-repetition proof.
// Run: bun .omo/evidence/20261021-pr3-components/row31/notice-wording.ts
import { chmodSync, mkdtempSync, writeFileSync } from "node:fs"
import { tmpdir } from "node:os"
import { join } from "node:path"

import { createCommentCheckerHooks } from "../../../../packages/omo-opencode/src/hooks/comment-checker/hook"

const unusableRunner = {
  initializeCommentCheckerCli: () => {},
  getCommentCheckerCliPathPromise: () => Promise.resolve(null),
  isCliPathUsable: () => false,
  processWithCli: async () => {},
  processApplyPatchEditsWithCli: async () => {},
}

async function main(): Promise<void> {
  console.log("=== case 1: the binary cannot be resolved ===")
  const hooks = createCommentCheckerHooks(undefined, unusableRunner)
  const first = { tool: "write", sessionID: "ses_notice_capture", callID: "call_1" }
  await hooks["tool.execute.before"](first, { args: { filePath: "/tmp/x.ts", content: "// c\n" } })
  const firstOutput = { title: "ok", output: "Success", metadata: {} }
  await hooks["tool.execute.after"](first, firstOutput)
  console.log(firstOutput.output)

  console.log("\n=== case 2: the same session edits again (bounded repetition) ===")
  const second = { tool: "write", sessionID: "ses_notice_capture", callID: "call_2" }
  await hooks["tool.execute.before"](second, { args: { filePath: "/tmp/y.ts", content: "// c\n" } })
  const secondOutput = { title: "ok", output: "Success", metadata: {} }
  await hooks["tool.execute.after"](second, secondOutput)
  console.log(secondOutput.output)

  console.log("\n=== case 3: the binary exists but exits outside its protocol ===")
  const dir = mkdtempSync(join(tmpdir(), "cc-notice-"))
  const binary = join(dir, "comment-checker")
  writeFileSync(binary, "#!/bin/sh\ncat >/dev/null\necho 'boom' 1>&2\nexit 3\n")
  chmodSync(binary, 0o755)
  const runner = {
    initializeCommentCheckerCli: () => {},
    getCommentCheckerCliPathPromise: () => Promise.resolve(binary),
    isCliPathUsable: () => true,
    processWithCli: async (
      _input: unknown,
      pendingCall: { sessionID: string; filePath: string; newString?: string },
      output: { output: string },
    ) => {
      const { processWithCli } = await import(
        "../../../../packages/omo-opencode/src/hooks/comment-checker/cli-runner"
      )
      await processWithCli(
        { tool: "write", sessionID: pendingCall.sessionID, callID: "call_3" },
        pendingCall as never,
        output,
        binary,
        undefined,
        () => {},
      )
    },
    processApplyPatchEditsWithCli: async () => {},
  }
  const failureHooks = createCommentCheckerHooks(undefined, runner)
  const third = { tool: "edit", sessionID: "ses_notice_failure", callID: "call_3" }
  await failureHooks["tool.execute.before"](third, {
    args: { filePath: "/tmp/z.ts", old_string: "const a = 1\n", new_string: "// c\nconst a = 1\n" },
  })
  const thirdOutput = { title: "ok", output: "Success", metadata: {} }
  await failureHooks["tool.execute.after"](third, thirdOutput)
  console.log(thirdOutput.output)
}

await main()

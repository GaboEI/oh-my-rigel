# Row 69 - QA & evidence summary

**Row:** `cat:K:instalacion-para-otras-ediciones` (audit row 69, PR3 components reconciliation)
**Classification:** PASS with evidence of real behavior
**Date:** 2026-10-21
**Worktree:** `/home/gabodev/oh-my-rigel-worktrees/reconcile-pr3-components-20261021` (branch `reconcile/pr3-components-20261021`)
**Sanctioned Senpi QA root:** `.omo/evidence/omo-senpi-adapter/20261021-pr3-senpi-install/` (resolved with `.agents/skills/senpi-qa/scripts/resolve-evidence-dir.mjs`)

## What was tested

| # | Surface driven | Behavior it had to prove |
|---|---|---|
| 1 | `packages/omo-senpi/src/install/plugin-artifacts.ts` (`REQUIRED_PLUGIN_ARTIFACTS`) checked against `packages/omo-senpi/plugin/` | The official route's payload is complete (C69.1) |
| 2 | `HOME=<sandbox>/home SENPI_CODING_AGENT_DIR=<sandbox>/agent node packages/omo-senpi/plugin/scripts/install.mjs install` | The official route completes, registers the plugin path, writes its settings backup (C69.2) |
| 3 | `<sandbox>/home/.local/bin/omo --version`, `--help`, `list` (no `OMO_SENPI_CLI_PATH`) | The installed launcher really starts the pinned engine and reports a real version; the engine loads the installed plugin (C69.3) |
| 4 | The same route from a plugin copy outside every dependency tree; a launcher whose engine file was removed | Missing engine = explicit named failure, never a silent broken launcher (C69.4) |
| 5 | `packages/omo-senpi/AGENTS.md`, `packages/omo-senpi/plugin/AGENTS.md`, `packages/omo-senpi/plugin/README.md` | The internal artifact contract and the documented commands are true (C69.5) |

## What was observed

- **C69.1** 41/41 required artifacts present, 0 missing.
- **C69.2** `{"ok":true,"action":"install","agentDir":"<sandbox>/agent","settingsPath":"<sandbox>/agent/settings.json","pluginPath":".../packages/omo-senpi/plugin","launcherPath":"<sandbox>/home/.local/bin/omo","changed":true,"backupPath":"<sandbox>/agent/settings.json.<ts>.backup"}`; the written `settings.json` lists the absolute plugin path; the rollback backup exists.
- **C69.3** The launcher was given the pinned dependency's CLI (`packages/omo-senpi/node_modules/@code-yeongyu/senpi/dist/bundle/cli.js`) and printed `local (senpi 2026.10.1-3)` (exit 0). `--help` answered under the `OmO` brand; `list` made the adapter's `model-profile` component answer, which only happens when the engine loaded the installed plugin extension. The trailing 401 is the credential-less sandbox's model-registry error, not a route defect.
- **C69.4** Route without an engine: `{"ok":false,"error":"no @code-yeongyu/senpi engine is installed: the resolver looked for node_modules/@code-yeongyu/senpi under <paths>. Install the pinned engine (bun add @code-yeongyu/senpi) or point OMO_SENPI_CLI_PATH at an existing senpi CLI"}`, exit 1, **no launcher and no agent dir written** (the failure precedes every state change). Launcher with a removed engine: `omo: the senpi engine is missing at <path>. Install @code-yeongyu/senpi (the engine this edition pins) or set OMO_SENPI_CLI_PATH to an existing senpi CLI.`, exit 1.
- **RED -> GREEN** Owner test `packages/omo-senpi/src/install/install-senpi-launcher.test.ts`: 3 failures for the right reason before the fix (the launcher pointed at a non-existent engine; the install "succeeded" with no engine at all; the launcher surfaced node's raw module error instead of an explicit message), then 35 pass / 0 fail across `packages/omo-senpi/src/install/`.
- **Gates** `bun run test:senpi` -> 4221 pass / 3 skip / 0 fail (508 files) + resolver test 10 pass, exit 0. `bun run typecheck` -> exit 0. `build-install.mjs --check` -> installer current.

## Why it is enough

The row's claim is behavioral ("install another supported edition"), so the proof had to be the official route itself, driven end to end in an isolated `HOME` + `SENPI_CODING_AGENT_DIR`: install -> settings written -> launcher on disk -> launcher boots the pinned engine -> engine reports a version -> engine loads the installed plugin. Every step above is an executed observation, not a source reading. The negative case proves the opposite failure mode cannot hide, and the unit owner test locks both behaviors for future changes.

## What was omitted

- No credentials, tokens or auth headers are recorded. The 401 body in `live-engine-boot.txt` is the engine's model-registry error for the credential-less sandbox, reproduced verbatim because it is the observable; it carries no secret.
- The live task/team QA drivers under `packages/omo-senpi/scripts/qa/` were **not** run: they need model credentials this sandbox does not have and they are not this row's surface. Labelled BLOCKED, not PASS. `senpi` is not on PATH here; the pinned engine package is installed and its CLI is what the installed launcher starts.
- The repo's own `bun run test:senpi` gate writes scratch files under the real `~/.senpi/agent/rpc/` and `~/.omo/run-continuation/` (pre-existing behavior of the package's RPC-host daemon tests). The route under test wrote nothing to real host state: `~/.local/bin/omo` does not exist and neither `~/.senpi/agent/settings.json` nor `~/.omo/agent/settings.json` was created or modified.

## Changed files

```
packages/omo-senpi/src/install/senpi-engine.ts               (new: the pinned-engine resolver)
packages/omo-senpi/src/install/install-senpi.ts              (resolve the engine before any state change)
packages/omo-senpi/src/install/local-launcher.ts              (explicit missing-engine failure; real version in the brand)
packages/omo-senpi/src/install/install-senpi-launcher.test.ts (owner test: RED -> GREEN cases)
packages/omo-senpi/src/install/cli-local.test.ts              (fixture provides the pinned engine the new contract requires)
packages/omo-senpi/AGENTS.md                                  (artifact contract truth)
packages/omo-senpi/plugin/AGENTS.md                           (artifact contract truth)
packages/omo-senpi/plugin/README.md                           (real install commands)
packages/omo-senpi/plugin/scripts/install.mjs                 (regenerated tracked installer build output; CI freshness gate)
```

No generated bundle churn: `git diff --name-only -- packages/omo-senpi/plugin/extensions packages/omo-senpi/plugin/runtime` prints nothing (the rebuilt bundles were restored to their committed bytes).

## Evidence index (sha256)

```
24db881ac36faa8058f131034f3e6c1339c11a4f716e8821be302987b27352a0  clean-tree.txt
8187bd843c3df8675c45c31446af0c1c9fa4339ad75935feab55852be26367de  green.txt
3cdb32100dd042a010db67e6eba4681cfa74f737dbeeab123ddce3af9fa407d6  install-proof.txt
c591cf59204fef5d0bc7335043e51a799e97181caa72b6e32004e7070955af10  install-result.json
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  install-stderr.txt
7cc4f8e22dd157a2329713b77cbc39177df99f3ac364f94c273f6f8e4440a9e0  launcher-version.txt
c580447ee279407251db0e3b49d272af811e4ffe7500b1d600c63664cac81151  live-engine-boot.txt
dda223502dd99fef69269b43710d320474dae186949dc7076d48c33640743390  no-engine.txt
0d1e50a2de8e58be6e88261670976f5b6e8de4941bf6359922f582532af62516  red.txt
b4c7b884c48aab8ea9af06dc46575dee97f0f97357222845631ac1a53a37dd6c  settings.json
2d25573920a60cc19c5a0ec141865c6814bd5b04be111fdcd07356e2ba49272a  test-senpi.txt
30ec57dba6b5d1c63b876d040bf2f123b43c217c5cdeaa4a637988d67746e1a9  typecheck.txt
```

## Residual risks

1. The engine path is baked at install time; moving the dependency tree afterwards requires a reinstall (the launcher then fails explicitly, and `OMO_SENPI_CLI_PATH` is the documented override).
2. The pin equality check only applies when a declaring manifest is discoverable and the spec is exact; a plugin installed outside the repo has no discoverable pin, so only "an engine exists" is enforced.
3. The install now FAILS when no engine is resolvable (deliberate contract change): a standalone plugin install must add `@code-yeongyu/senpi@2026.10.1-3` or set `OMO_SENPI_CLI_PATH`.
4. The local brand's `displayVersion` changed from `"local"` to `"local (senpi <version>)"`; a side effect is that the memory worker's reflection-launcher runtime identity now records the engine version string instead of `"local"`.
5. `build-extension.mjs --check` reports `stale-output` in this worktree even on a pristine HEAD checkout (environmental drift, proven unrelated to this row by an A/B of the build marker).

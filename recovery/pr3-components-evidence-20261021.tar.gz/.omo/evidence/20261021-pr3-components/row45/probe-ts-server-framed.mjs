#!/usr/bin/env node
// Direct probe of typescript-language-server using LSP Content-Length framing.
import { spawn } from "node:child_process";
import { pathToFileURL } from "node:url";
import { readFileSync } from "node:fs";

const BIN = "/tmp/opencode/row45-lsp/node_modules/.bin/typescript-language-server";
const ROOT = "/tmp/opencode/row45-ws";
const FILE = `${ROOT}/src/broken.ts`;
const TEXT = readFileSync(FILE, "utf8");

const T0 = Date.now();
const child = spawn(BIN, ["--stdio"], { cwd: ROOT, stdio: ["pipe", "pipe", "pipe"] });
child.stderr.on("data", (c) => process.stderr.write(`[srv-stderr] ${c}`));

let buffer = Buffer.alloc(0);
const pending = new Map();
child.stdout.on("data", (chunk) => {
	buffer = Buffer.concat([buffer, chunk]);
	for (;;) {
		const headerEnd = buffer.indexOf("\r\n\r\n");
		if (headerEnd < 0) break;
		const header = buffer.slice(0, headerEnd).toString("utf8");
		const match = /Content-Length:\s*(\d+)/i.exec(header);
		if (!match) {
			buffer = buffer.slice(headerEnd + 4);
			continue;
		}
		const length = Number(match[1]);
		const start = headerEnd + 4;
		if (buffer.length < start + length) break;
		const body = buffer.slice(start, start + length).toString("utf8");
		buffer = buffer.slice(start + length);
		let msg;
		try {
			msg = JSON.parse(body);
		} catch {
			continue;
		}
		if (msg.id !== undefined && pending.has(msg.id)) {
			pending.get(msg.id)(msg);
			pending.delete(msg.id);
			continue;
		}
		if (msg.method === "textDocument/publishDiagnostics") {
			const p = msg.params;
			process.stdout.write(`[publish +${Date.now() - T0}ms] ${p.uri} count=${p.diagnostics.length} version=${p.version}\n`);
			for (const d of p.diagnostics) {
				process.stdout.write(`   ${d.range.start.line + 1}:${d.range.start.character + 1} ${d.code ?? ""} ${d.message}\n`);
			}
		}
	}
});

function send(msg) {
	const body = Buffer.from(JSON.stringify(msg), "utf8");
	child.stdin.write(`Content-Length: ${body.length}\r\n\r\n`);
	child.stdin.write(body);
}
function request(msg, timeoutMs = 30000) {
	return new Promise((resolve) => {
		pending.set(msg.id, resolve);
		send(msg);
		setTimeout(() => {
			if (pending.has(msg.id)) {
				pending.delete(msg.id);
				resolve({ timeout: true, id: msg.id });
			}
		}, timeoutMs);
	});
}

const init = await request({
	jsonrpc: "2.0",
	id: 1,
	method: "initialize",
	params: {
		processId: process.pid,
		rootUri: pathToFileURL(ROOT).href,
		workspaceFolders: [{ uri: pathToFileURL(ROOT).href, name: "workspace" }],
		capabilities: { textDocument: { publishDiagnostics: { relatedInformation: true } } },
	},
});
process.stdout.write(`[init] diagnosticProvider=${JSON.stringify(init.result?.capabilities?.diagnosticProvider)}\n`);
send({ jsonrpc: "2.0", method: "initialized", params: {} });
send({
	jsonrpc: "2.0",
	method: "textDocument/didOpen",
	params: {
		textDocument: { uri: pathToFileURL(FILE).href, languageId: "typescript", version: 1, text: TEXT },
	},
});
await new Promise((r) => setTimeout(r, 10000));
child.kill("SIGTERM");
process.exit(0);

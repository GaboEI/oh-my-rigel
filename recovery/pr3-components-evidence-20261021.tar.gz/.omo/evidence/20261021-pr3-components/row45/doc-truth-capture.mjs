#!/usr/bin/env node
// row45 doc-truth capture: the delivered tools/list vs the internal doc claims.
import { readFileSync, writeFileSync } from "node:fs";

const E = "/home/gabodev/oh-my-rigel-worktrees/reconcile-pr3-components-20261021/.omo/evidence/20261021-pr3-components/row45";
const REPO = "/home/gabodev/oh-my-rigel-worktrees/reconcile-pr3-components-20261021";

const raw = readFileSync(`${E}/tools-list.json`, "utf8");
const responses = raw
	.split("\n---\n")
	.map((chunk) => chunk.split("=== RAW STDERR ===")[0].trim())
	.filter(Boolean)
	.map((chunk) => JSON.parse(chunk));
const listResponse = responses.find((r) => r.id === 2);
const tools = listResponse.result.tools.map((tool) => tool.name);
const aliases = tools.map((name) => `lsp_${name}`);

const lines = [];
lines.push("# row45 doc truth capture");
lines.push("");
lines.push("## Delivered tools/list (real subprocess, packages/lsp-tools-mcp/dist/cli.js mcp)");
lines.push(`tool count: ${tools.length}`);
for (const tool of tools) lines.push(`- ${tool}`);
lines.push("");
lines.push("## Callable aliases (every alias verified by a real tools/call in aliases-result.json)");
for (const alias of aliases) lines.push(`- ${alias}`);
lines.push("");

const docFiles = [
	"packages/lsp-core/AGENTS.md",
	"packages/lsp-tools-mcp/AGENTS.md",
	"packages/lsp-tools-mcp/README.md",
	"packages/AGENTS.md",
	"AGENTS.md",
];

lines.push("## Internal doc lines that state the LSP tool surface");
for (const file of docFiles) {
	const content = readFileSync(`${REPO}/${file}`, "utf8").split("\n");
	content.forEach((text, index) => {
		if (!/lsp_/.test(text)) return;
		if (!/lsp_|LSP/.test(text)) return;
		if (text.trim().startsWith("- `lsp_")) {
			lines.push(`${file}:${index + 1}: ${text.trim()}`);
			return;
		}
		if (/alias|Tool surface|tool schemas|exposes|serves/i.test(text)) {
			lines.push(`${file}:${index + 1}: ${text.trim()}`);
		}
	});
}
lines.push("");

const joined = lines.join("\n");
writeFileSync(`${E}/doc-truth.txt`, joined, "utf8");
process.stdout.write(`${joined}\n`);

#!/usr/bin/env node
// row45 evidence driver: drives the DELIVERED lsp stdio MCP server as a real
// subprocess and captures the raw JSON-RPC responses.
//
// usage: node mcp-drive.mjs <scenario.json> <out.jsonl>
// scenario.json: { cli, cwd, env: {...}, calls: [ {method, params?} ], timeoutMs? }
import { spawn } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";

const [scenarioPath, outPath] = process.argv.slice(2);
if (!scenarioPath || !outPath) {
	process.stderr.write("usage: node mcp-drive.mjs <scenario.json> <out.jsonl>\n");
	process.exit(2);
}

const scenario = JSON.parse(readFileSync(scenarioPath, "utf8"));
const timeoutMs = scenario.timeoutMs ?? 120000;

const child = spawn(process.execPath, [scenario.cli, "mcp"], {
	cwd: scenario.cwd,
	env: { ...process.env, ...scenario.env },
	stdio: ["pipe", "pipe", "pipe"],
});

const raw = [];
const stderrChunks = [];
child.stderr.on("data", (chunk) => stderrChunks.push(chunk));
child.stdout.on("data", (chunk) => {
	for (const line of chunk.toString("utf8").split("\n")) {
		if (line.trim().length === 0) continue;
		raw.push(line);
	}
});

function send(payload) {
	child.stdin.write(`${JSON.stringify(payload)}\n`);
}

function waitFor(predicate, label) {
	return new Promise((resolve, reject) => {
		const started = Date.now();
		const timer = setInterval(() => {
			const index = raw.findIndex((line) => {
				try {
					return predicate(JSON.parse(line));
				} catch {
					return false;
				}
			});
			if (index >= 0) {
				clearInterval(timer);
				resolve(JSON.parse(raw[index]));
				return;
			}
			if (Date.now() - started > timeoutMs) {
				clearInterval(timer);
				reject(new Error(`timeout waiting for ${label} after ${timeoutMs}ms`));
			}
		}, 25);
	});
}

async function main() {
	send({ jsonrpc: "2.0", id: 1, method: "initialize", params: { protocolVersion: "2024-11-05", capabilities: {}, clientInfo: { name: "row45-driver", version: "0.0.0" } } });
	const initResponse = await waitFor((msg) => msg.id === 1, "initialize response");
	send({ jsonrpc: "2.0", method: "notifications/initialized", params: {} });

	const responses = [initResponse];
	let id = 2;
	for (const call of scenario.calls ?? []) {
		if (typeof call.delayMs === "number") {
			await new Promise((resolve) => setTimeout(resolve, call.delayMs));
			continue;
		}
		send({ jsonrpc: "2.0", id, method: call.method, params: call.params ?? {} });
		const response = await waitFor((msg) => msg.id === id, `${call.method} response`);
		responses.push(response);
		id += 1;
	}

	writeFileSync(
		outPath,
		`${responses.map((response) => JSON.stringify(response, null, 2)).join("\n---\n")}\n\n=== RAW STDERR ===\n${stderrChunks.join("")}\n`,
		"utf8",
	);
	process.stderr.write(`wrote ${outPath} (${responses.length} responses)\n`);
	child.stdin.end();
	child.kill("SIGTERM");
}

main().catch((error) => {
	process.stderr.write(`driver failed: ${error instanceof Error ? error.stack : String(error)}\n`);
	writeFileSync(
		outPath,
		`DRIVER FAILURE: ${error instanceof Error ? error.message : String(error)}\n\n=== RAW RESPONSES ===\n${raw.join("\n")}\n\n=== RAW STDERR ===\n${stderrChunks.join("")}\n`,
		"utf8",
	);
	child.kill("SIGTERM");
	process.exit(1);
});

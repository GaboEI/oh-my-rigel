#!/usr/bin/env node
// Generates the three row45 scenarios (surface / real-lsp / missing-server).
import { writeFileSync } from "node:fs";

const REPO = "/home/gabodev/oh-my-rigel-worktrees/reconcile-pr3-components-20261021";
const CLI = `${REPO}/packages/lsp-tools-mcp/dist/cli.js`;
const WS = "/tmp/opencode/row45-ws";
const CFG = "/tmp/opencode/row45-cfg";
const TMP_BIN = "/tmp/opencode/row45-lsp/node_modules/.bin";
const BROKEN = `${WS}/src/broken.ts`;

const baseEnv = {
	LSP_TOOLS_MCP_CWD: WS,
	LSP_TOOLS_MCP_PROJECT_CONFIG: `${WS}/.codex/lsp-client.json`,
	LSP_TOOLS_MCP_INSTALL_DECISIONS: `${CFG}/lsp-install-decisions.json`,
};

const realServerEnv = {
	...baseEnv,
	LSP_TOOLS_MCP_USER_CONFIG: `${CFG}/user-lsp.json`,
	PATH: `${TMP_BIN}:${process.env.PATH}`,
};

const missingServerEnv = {
	...baseEnv,
	LSP_TOOLS_MCP_USER_CONFIG: `${CFG}/missing-server-lsp.json`,
	PATH: process.env.PATH,
};

const scenarios = {
	"scenario-surface.json": {
		cli: CLI,
		cwd: WS,
		env: realServerEnv,
		calls: [{ method: "tools/list" }],
	},
	"scenario-real-lsp.json": {
		cli: CLI,
		cwd: WS,
		env: realServerEnv,
		timeoutMs: 180000,
		calls: [
			{ method: "tools/call", params: { name: "status", arguments: {} } },
			{ method: "tools/call", params: { name: "lsp_diagnostics", arguments: { filePath: BROKEN } } },
			{ method: "tools/call", params: { name: "lsp_symbols", arguments: { filePath: BROKEN, scope: "document" } } },
		],
	},
	"scenario-missing-server.json": {
		cli: CLI,
		cwd: WS,
		env: missingServerEnv,
		timeoutMs: 180000,
		calls: [
			{ method: "tools/call", params: { name: "status", arguments: {} } },
			{ method: "tools/call", params: { name: "lsp_diagnostics", arguments: { filePath: BROKEN } } },
			{
				method: "tools/call",
				params: { name: "lsp_install_decision", arguments: { server_id: "typescript", decision: "declined" } },
			},
			{ method: "tools/call", params: { name: "lsp_diagnostics", arguments: { filePath: BROKEN } } },
		],
	},
};

for (const [name, scenario] of Object.entries(scenarios)) {
	writeFileSync(`${process.argv[2]}/${name}`, `${JSON.stringify(scenario, null, 2)}\n`, "utf8");
	process.stdout.write(`wrote ${name}\n`);
}

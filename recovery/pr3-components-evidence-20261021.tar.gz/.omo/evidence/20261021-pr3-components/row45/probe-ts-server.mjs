#!/usr/bin/env node
// Direct probe of typescript-language-server to see what diagnostics it publishes.
import { spawn } from "node:child_process";
import { pathToFileURL } from "node:url";

const BIN = "/tmp/opencode/row45-lsp/node_modules/.bin/typescript-language-server";
const ROOT = "/tmp/opencode/row45-ws";
const FILE = `${ROOT}/src/broken.ts`;
const TEXT = `export interface Row45Shape {
\tid: number;
\tlabel: string;
}

export function describeRow45(shape: Row45Shape): string {
\treturn shape.label;
}

const bad: Row45Shape = { id: "not-a-number", label: 42 };
`;

const child = spawn(BIN, ["--stdio"], { cwd: ROOT, stdio: ["pipe", "pipe", "pipe"] });
child.stderr.on("data", (c) => process.stderr.write(`[srv-stderr] ${c}`));

let buffer = "";
const pending = new Map();
child.stdout.on("data", (chunk) => {
	buffer += chunk.toString("utf8");
	let index;
	while ((index = buffer.indexOf("\n")) >= 0) {
		const line = buffer.slice(0, index).trim();
		buffer = buffer.slice(index + 1);
		if (!line) continue;
		let msg;
		try {
			msg = JSON.parse(line);
		} catch {
			continue;
		}
		if (msg.id !== undefined && pending.has(msg.id)) {
			pending.get(msg.id)(msg);
			pending.delete(msg.id);
			continue;
		}
		if (msg.method === "textDocument/publishDiagnostics") {
			const p = msg.params;
			process.stdout.write(`[publish] ${p.uri} diagnostics=${p.diagnostics.length}\n`);
			for (const d of p.diagnostics) {
				process.stdout.write(`   ${d.range.start.line + 1}:${d.range.start.character + 1} ${d.code ?? ""} ${d.message}\n`);
			}
		}
	}
});

function send(msg) {
	child.stdin.write(`${JSON.stringify(msg)}\n`);
}
function request(msg, timeoutMs = 60000) {
	return new Promise((resolve) => {
		pending.set(msg.id, resolve);
		send(msg);
		setTimeout(() => {
			if (pending.has(msg.id)) {
				pending.delete(msg.id);
				resolve({ timeout: true, id: msg.id });
			}
		}, timeoutMs);
	});
}

const init = await request({
	jsonrpc: "2.0",
	id: 1,
	method: "initialize",
	params: {
		processId: process.pid,
		rootUri: pathToFileURL(ROOT).href,
		workspaceFolders: [{ uri: pathToFileURL(ROOT).href, name: "workspace" }],
		capabilities: { textDocument: { publishDiagnostics: { relatedInformation: true } } },
	},
});
process.stdout.write(`[init] capabilities.diagnosticProvider=${JSON.stringify(init.result?.capabilities?.diagnosticProvider)}\n`);
send({ jsonrpc: "2.0", method: "initialized", params: {} });
send({
	jsonrpc: "2.0",
	method: "textDocument/didOpen",
	params: {
		textDocument: { uri: pathToFileURL(FILE).href, languageId: "typescript", version: 1, text: TEXT },
	},
});
await new Promise((r) => setTimeout(r, 6000));

const pull = await request({
	jsonrpc: "2.0",
	id: 2,
	method: "textDocument/diagnostic",
	params: { textDocument: { uri: pathToFileURL(FILE).href } },
});
process.stdout.write(`[pull] ${JSON.stringify(pull).slice(0, 3000)}\n`);
child.kill("SIGTERM");
process.exit(0);

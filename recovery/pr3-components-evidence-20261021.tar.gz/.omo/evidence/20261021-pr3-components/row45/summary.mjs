#!/usr/bin/env node
// row45 decisive-excerpt summary built from the captured raw artifacts.
import { readFileSync, writeFileSync } from "node:fs";

const E = "/home/gabodev/oh-my-rigel-worktrees/reconcile-pr3-components-row45-placeholder";

function load(file) {
	const raw = readFileSync(`${process.argv[2]}/${file}`, "utf8");
	return raw
		.split("\n---\n")
		.map((chunk) => chunk.split("=== RAW STDERR ===")[0].trim())
		.filter(Boolean)
		.map((chunk) => {
			try {
				return JSON.parse(chunk);
			} catch {
				return null;
			}
		})
		.filter(Boolean);
}

function textOf(message) {
	const content = message?.result?.content;
	if (!Array.isArray(content) || content.length === 0) return JSON.stringify(message?.error ?? message);
	return content.map((entry) => entry.text ?? JSON.stringify(entry)).join("\n");
}

const out = [];
out.push("# row45 decisive excerpts (all captured from real subprocess runs)");
out.push("");

const surface = load("tools-list.json");
const toolList = surface.find((r) => r.id === 2);
out.push("## C45.1 SURFACE - tools/list from `node packages/lsp-tools-mcp/dist/cli.js mcp`");
out.push(`serverInfo: ${JSON.stringify(surface.find((r) => r.id === 1).result.serverInfo)}`);
out.push(`tool count: ${toolList.result.tools.length}`);
out.push(`tool names: ${toolList.result.tools.map((t) => t.name).join(", ")}`);
out.push("");

const real = load("real-lsp-result.json");
out.push("## C45.2 REAL LANGUAGE SERVER (typescript-language-server from /tmp prefix)");
for (const message of real.filter((r) => r.id >= 3)) {
	const text = textOf(message);
	if (message.id === 3) {
		out.push(`[call ${message.id}] lsp_diagnostics (cold, first call): ${text}`);
	} else if (message.id === 4) {
		out.push(`[call ${message.id}] lsp_diagnostics (warm, after the semantic publish): ${text}`);
	} else if (message.id === 5) {
		out.push(`[call ${message.id}] lsp_symbols: ${text}`);
	} else if (message.id === 6) {
		out.push(`[call ${message.id}] lsp_goto_definition: ${text}`);
	}
}
out.push("");

const aliases = load("aliases-result.json");
out.push("## alias coverage (every `lsp_*` alias invoked by name over the same stdio transport)");
const aliasScenario = JSON.parse(readFileSync(`${process.argv[2]}/scenario-aliases.json`, "utf8"));
let aliasId = 2;
for (const call of aliasScenario.calls) {
	if (typeof call.delayMs === "number") continue;
	const message = aliases.find((r) => r.id === aliasId);
	aliasId += 1;
	if (!message) continue;
	out.push(`[call ${message.id}] ${call.params.name} -> ${textOf(message).split("\n")[0]}`);
}
out.push("");

const missing = load("missing-server-result.json");
const aliases2 = load("aliases-result-2.json");
const aliasScenario2 = JSON.parse(readFileSync(`${process.argv[2]}/scenario-aliases-2.json`, "utf8"));
let aliasId2 = 2;
for (const call of aliasScenario2.calls) {
	if (typeof call.delayMs === "number") continue;
	const message = aliases2.find((r) => r.id === aliasId2);
	aliasId2 += 1;
	if (!message) continue;
	out.push(`[call ${message.id}] ${call.params.name} -> ${textOf(message).split("\n")[0]}`);
}
out.push("");

out.push("## C45.3 FAIL-CLOSED (no language server resolvable)");
for (const message of missing.filter((r) => r.id >= 3)) {
	out.push(`[call ${message.id}] ${textOf(message)}`);
	out.push("");
}
out.push("");

out.push("## C45.4 DOC TRUTH");
out.push(readFileSync(`${process.argv[2]}/doc-truth.txt`, "utf8"));

writeFileSync(`${process.argv[2]}/row45-summary.txt`, out.join("\n"), "utf8");
process.stdout.write(`${out.join("\n")}\n`);
